<?php
/*
 * Plugin Name: Importer
 * Plugin URI: https://sellix.io/product/5f25c5ce93203
 * Description: Plugin for automatic import of movie informations from TMDB exclusively for the Moviewp Theme. You can also buy a PREMIUM version here <a target="_blank" href="https://sellix.io/product/5fe091e66f87a">here</a>
 * Version: 4.0
 * Author: fr0zen
 * Author URI: https://sellix.io/fr0zen
 * License: License Limited
 * License URI: https://sellix.io/fr0zen
 * Copyright:  Vincenzo Piromalli
 * Text Domain: importer
 */

define("Importer",plugin_basename(__FILE__));
define("PLUGIN_DIR",__DIR__);

require_once PLUGIN_DIR."/vendor/autoload.php";

if(is_admin()){
    $moviewp = new \App\Bootstrap();
}
