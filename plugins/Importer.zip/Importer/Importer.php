<?php
/*
 * Plugin Name: Importer
 * Plugin URI: https://github.com/VincenzoPiromalli/moviewp/blob/main/plugins/Importer.zip
 * Description: Plugin for automatic import of movie informations from TMDB exclusively for the Moviewp Theme. You can also buy a PREMIUM version here <a target="_blank" href="mailto:vpiromalli74@gmail.com">here</a>
 * Version: 5.0
 * Author: VincenzoPiromalli
 * Author URI: https://github.com/VincenzoPiromalli
 * License: GNU General Public License v2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Text Domain: importer
 */

define("Importer",plugin_basename(__FILE__));
define("PLUGIN_DIR",__DIR__);

require_once PLUGIN_DIR."/vendor/autoload.php";

if(is_admin()){
    $moviewp = new \App\Bootstrap();
}
