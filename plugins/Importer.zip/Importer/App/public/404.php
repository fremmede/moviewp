<?php
/**
 * Created by PhpStorm.
 * User: fr0zen
 * Date: 22/12/2020
 * Time: 07:38 PM
 */

?>
<div class="wrap" style="text-align: center;">
    <img src="<?php echo plugin_dir_url(__FILE__); ?>/assets/images/404.png" alt="404 Page" style="max-width: 100%;">
</div>