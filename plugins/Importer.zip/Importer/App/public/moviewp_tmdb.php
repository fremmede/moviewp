<?php
/**
 * Created by PhpStorm.
 * User: fr0zen
 * Date: 22/12/2020
 * Time: 07:38 PM
 */
?>
<div class="wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__( 'Movie Importer', 'importer' ) ?></h1>
    <span class="premium"><?php echo esc_html__( 'Go ', 'importer' ) ?><a class="flashit" href="<?php echo esc_url('mailto:vpiromalli74@gmail.com'); ?>"><?php echo esc_html__( 'PREMIUM', 'importer' ) ?></a></span>
    <hr class="wp-header-end">
    <div id="poststuff">
        <div id="post-body" class="metabox-holder columns-2">
            <div id="postbox-container-1" class="postbox-container">
                <div id="side-sortables" class="meta-box-sortables ui-sortable ui-sortable-disabled">
                    <div id="submitdiv" class="postbox">
                        <h2 class="hndle ui-sortable-handle"><span><?php echo esc_html__( 'Movie Search', 'importer' ) ?></span></h2>
                        <div class="inside">
                            <form data-view="tmdb_result" data-callback="show_tmdb_search" data-method="post" id="tmdb_search" class="moviewp_form">
                                <div class="submitbox" id="submitpost">
                                    <div id="minor-publishing">
                                        <div id="minor-publishing-actions" style="text-align: left">
                                            <label class="font-weight-normal mtt"><?php echo esc_attr__( 'Movie Title', 'importer' ) ?></label>
                                            <input type="hidden" name="page" id="page" value="<?php esc_attr_e( '1', 'importer' ); ?>">
                                            <input type="hidden" value="<?php esc_attr_e( 'SearchMovie', 'importer' ); ?>" name="action">
                                            <p><input class="font-weight-normal" type="text" required autofocus name="movie_title" id="movie_title" style="min-width: 100%; text-align: left;" placeholder="<?php esc_attr_e( 'Title or initial letter...', 'importer' ); ?>"></p>
                                            
                                            <label style="display:none;" class="mtt"><?php echo esc_attr__( 'Language', 'importer' ) ?></label>
                                            <p><select style="display:none;" name="language" id="language" style="width: 100%">
                                                <option value="<?php echo apilanguage; ?>" selected><?php echo esc_attr__( 'Default', 'importer' ) ?></option>
                                            </p></select>
                                        </div>
                                        <div class="clear"></div>
                                    </div>
                                    <div id="major-publishing-actions">
                                        <div id="publishing-action">
                                            <span class="spinner"></span>
                                            <button type="button" id="publish" class="button button-cancel button-large btn btn-primary" style="display: none;"><?php echo esc_attr__( 'New Search', 'importer' ) ?></button>
                                            <button type="submit" id="publish" class="button button-primary button-large btn btn-primary"><?php echo esc_attr__( 'Search', 'importer' ) ?></button>
                                        </div>
                                        <div class="clear"></div>
                                    </div>
                                </div>
                            </form>
                            <form data-callback="show_movie_add" data-method="post" id="tmdb_movie_add" class="moviewp_form" data-view="tmdb_api">
                                <input type="hidden" value="<?php esc_attr_e( 'AddMovie', 'importer' ); ?>" name="action" required>
                                <input type="hidden" value="" id="tmdb_movie_id" name="tmdb_movie_id" required>
                                <input type="hidden" name="tmdb_language" id="tmdb_language" value="<?php esc_attr_e( 'en-US', 'importer' ); ?>">
                                <div class="tmdb_api" style="align-t"></div>
                            </form>
                        </div>
                    </div>
                </div>
                <div id="tags"></div>
            </div>
            <div class="postbox-container" id="post-body">
                <div id="submitdiv" class="postbox">
                    <h2 class="hndle ui-sortable-handle" style="text-align: center"><span><?php echo esc_html__( 'Results: ', 'importer' ) ?><span class="result_page"></span></span></h2>
                    <div class="inside">
                        <div class="submitbox" id="submitpost">
                            <div id="minor-publishing" class="tmdb_result" style="padding: 15px;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>