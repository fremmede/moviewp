<?php
/**
 * Created by PhpStorm.
 * User: VincenzoPiromalli
 * Date: 23/09/2021
 * Time: 07:38 PM
 */

namespace App\Traits;

trait Boot {

    private $configuration = null;

    public function AddMovieLinks(){
        $movie_id = @$_POST['post_id'];
        $post = get_post($movie_id);
        if(gettype($post) == null || gettype($post) == "NULL"){
            $this->show_header_error("The id of the post does not exist in the system");
        }else{
            $web_name = $this->getClassName($_POST['link_boot']);
            if(in_array($web_name,get_class_methods($this))){

            }else{
                $this->show_header_error('Sorry, we do not have support for this web.');
            }
        }
        exit();
    }
	//movies
    public function SearchMovie(){
        $this->configuration = $this->GetAPIConfiguration()->response;
        echo header('Content-Type: application/json');
        $movies = @$this->SearchMovies(@$_POST['movie_title'],@$_POST['language'],@$_POST['page'],@$_POST['content_adult'])->response;
        if(@$movies->total_results > 0){
            $result = array();
            foreach (@$movies->results as $index => $value){
                if($value->poster_path!=''){
					@$result[$index]->title = str_replace("'", " ", $value->title);
					@$result[$index]->title = str_replace('"', ' ', $value->title);
					@$result[$index]->post_slug = ''.get_site_url().'/'.sanitize_title( @$result[$index]->title);
                    @$result[$index]->id = $value->id;
                    @$result[$index]->poster = @$this->configuration->images->secure_base_url.$this->configuration->images->poster_sizes[1].$value->poster_path;
                    @$result[$index]->release_date = @explode("-",@$value->release_date)[0];
	                if($this->get_post_by_slug("name",sanitize_title( @$result[$index]->title)) || $this->get_post_by_slug("title", @$result[$index]->title)){
					@$result[$index]->clas = "added animated bounceOutUp";
                    } else { 
					@$result[$index]->clas = "none";
					}
                }
            }
        }
        @$movies->results = $result;
        echo wp_json_encode($movies);
        exit();
    }

    public function AddMovie(){
        $movie_id = @$_POST['tmdb_movie_id'];
        $movie = $this->GetMovieDetails($movie_id,@$_POST['tmdb_language'])->response;
        if(@$movie->id == @$_POST['tmdb_movie_id']){
            $this->configuration = $this->GetAPIConfiguration()->response;
            $genres = array();
            foreach ($movie->genres as $index => $value){
                if(in_array($_POST['tmdb_language'],["en-US","fr-FR","es-ES","it-IT"])){
                    $value->name = str_replace(array("Suspense"),array("Thriller"),$value->name);
                }
                if(get_the_category_by_ID(1)=='Uncategorized'){
                    wp_update_term(1,"category",[
                        "name"=>@$value->name,
                        "slug"=>sanitize_title(@$value->name)
                    ]);
                    array_push($genres,1);
                }else{
                    $isCat = get_category_by_slug(sanitize_title(@$value->name));
                    if(@$isCat->term_id != ''){
                        array_push($genres,@$isCat->term_id);
                    }else{
                        $idcat= wp_insert_category([
                            "cat_name"=>@$value->name,
                            "category_nicename"=>sanitize_title(@$value->name),
                            "category_parent"=>"",
                            "category_description"=>@$value->name
                        ]);
                        array_push($genres,$idcat);
                    }
                }
            }

            if($this->get_post_by_slug("name",sanitize_title($movie->title)) || $this->get_post_by_slug("title",$movie->title)){
                $this->show_header_error("The title '".@$movie->title."' already exists");
            }else{
                $new_post = [
                    "post_title"=>$movie->title,
                    "post_name"=>sanitize_title($movie->title),
                    "post_content" =>$movie->overview,
                    "post_excerpt"=>$movie->overview,
                    "post_category"=>$genres,
                    "post_status"=>"publish"
                ];

                $POST_ID = wp_insert_post($new_post);
                if(@$POST_ID){
                    $stars = $director = $cast = array();
                    /**
                     * We look for the cast of the movie and store it in a variable
                     */
                    $credits = $this->GetMovieCast($movie_id)->response;
                    if(sizeof($credits->cast)>0){
                        foreach ($credits->cast as $index => $actor){
                            @$cast[$index] = $actor->name;
                            if($index<3){
                                @$stars[$index] = $actor->name;
                            }
                        }
                        $cast = implode(",",$cast);
                        $stars = implode(",",$stars);
                    }
                    /**
                     * We look for the directors of the movie and store them in a variable
                     */
                    $credits = $this->GetMovieCrew($movie_id)->response;
                    if(sizeof($credits->crew)>0){
                        foreach ($credits->crew as $index => $crew){
                            if($crew->job == 'Director'){
                                @$director[$index]=$crew->name;
                            }
                        }
                        $director = implode(",",$director);
                    }

                    /**
                     * We retrieve the Movie MPAA Certification
                     */
                    $releases = $this->GetMovieCertification($movie_id)->response;
                    if(sizeof($releases->countries)>0){
                        foreach ($releases->countries as $index => $countries){
                            if($countries->iso_3166_1 == 'US'){
                                @$certification[$index]=$countries->certification;
								add_post_meta($POST_ID,"Rated",@$certification[$index]=$countries->certification);
                            }
                        }
                    }

                    /**
                     * We retrieve the trailers of the searched movie and store them in a variable
                     */
                    $trailers = $this->GetMovieVideos($movie_id,apilanguage)->response;
                    if(sizeof($trailers->results)>0){
                        $arr=array();
                        foreach ($trailers->results as $index => $value){
                                @$arr[$index] = @$value->key;
                        }
                        $trailers="".@$arr[0]."";
						if($trailers == ''){
                        $trailers = "";
                        }
                        } else {
					    $trailers = "";
                        }
                    /**
                     * We retrieve the images of the searched movie and store it in a variable
                     */
                    $images = @$this->GetMovieBackdrops($movie_id)->response;
                    if(sizeof($images->backdrops)>0){
                        if(sizeof($images->backdrops) > 10){
                            $limit = 10;
                        }else{
                            $limit = sizeof($images->backdrops);
                        }
                        $backdrops = array();
                        for($i=0;$i<$limit;$i++){
                            @$backdrops[$i] = @$this->configuration->images->secure_base_url.$this->configuration->images->backdrop_sizes[1].$images->backdrops[$i]->file_path;
                        }
                        $backdrops = implode(",",$backdrops);
                    }
                    /*
                    if(@$movie->poster_path!=''){
                    $image_url        = trim(@$this->configuration->images->secure_base_url.$this->configuration->images->poster_sizes[3].$movie->poster_path);
                    $image_name       = trim($movie->title).".jpg";
                    $upload_dir       = wp_upload_dir(); // Set upload folder
                    $image_data       = file_get_contents($image_url); // Get image data
                    $unique_file_name = wp_unique_filename( $upload_dir['path'], $image_name ); // Generate unique name
                    $filename         = basename( $unique_file_name ); // Create image file name

                    // Check folder permission and define file location
                    if( wp_mkdir_p( $upload_dir['path'] ) ) {
                    $file = $upload_dir['path'] . '/' . $filename;
                    } else {
                    $file = $upload_dir['basedir'] . '/' . $filename;
                    }

                    // Create the image  file on the server
                    file_put_contents( $file, $image_data );

                    // Check image file type
                    $wp_filetype = wp_check_filetype( $filename, null );

                    // Set attachment data
                    $attachment = array(
                    'post_mime_type' => $wp_filetype['type'],
                    'post_title'     => sanitize_file_name( $filename ),
                    'post_content'   => false,
                    'post_status'    => 'inherit'
                    );

                    // Create the attachment
                    $attach_id = wp_insert_attachment( $attachment, $file, $POST_ID );

                    // Include image.php
                    require_once(ABSPATH . 'wp-admin/includes/image.php');

                    // Define attachment metadata
                    $attach_data = wp_generate_attachment_metadata( $attach_id, $file );

                    // Assign metadata to attachment
                    wp_update_attachment_metadata( $attach_id, $attach_data );

                    // And finally assign featured image to post
                    set_post_thumbnail( $POST_ID, $attach_id );
                    }
                    */
                    
					$country = @$movie->production_countries[0]->name;
					$country = str_replace(array("United Kingdom"),array("UK"),$country);
					$country = str_replace(array("United States of America"),array("USA"),$country);
                    
                    add_post_meta($POST_ID,"imdb_id",trim($movie->imdb_id));
                    add_post_meta($POST_ID,"id",trim($movie->id));
                    add_post_meta($POST_ID,"Runtime",trim($movie->runtime)." min");
                    add_post_meta($POST_ID,"vote_average",trim($movie->vote_average));
                    add_post_meta($POST_ID,"imdbRating",trim($movie->vote_average));
                    add_post_meta($POST_ID,"poster_path",trim($movie->poster_path));
                    add_post_meta($POST_ID,"backdrop_path",trim($movie->backdrop_path));
                    add_post_meta($POST_ID,"tagline",trim($movie->tagline));
                    add_post_meta($POST_ID,"youtube_id",$trailers);
                    add_post_meta($POST_ID,"release_date",trim(@explode("-",@$movie->release_date)[0]));
                    
                    wp_set_post_terms($POST_ID,@explode("-",@$movie->release_date)[0], "years");
                    wp_set_post_terms($POST_ID,$stars,"actors");
                    wp_set_post_terms($POST_ID,$director,"director");
					wp_set_post_terms($POST_ID,$country,"country");
                    wp_set_post_terms($POST_ID,$genres,"category");
                    
					//$category_ids = array(2);
                    //wp_set_post_categories( $POST_ID, $category_ids, 'category');
                    $category_movies = get_cat_ID( 'Movies' );
                    wp_set_post_categories( $POST_ID, $category_movies, 'category');
                    
                    $this->response_json([
                        "id"=>$POST_ID,
                        "title"=>$movie->title,
                        "permalink"=>get_post_permalink($POST_ID)
                    ],true);
                }else{
                    $this->show_header_error("The movie was not added");
                }
            }
        }else{
            header("HTTP/1.0 500 Incorrect Request: The id is not appropriate");
            exit();
        }
        echo $this->response_json($movie,true);
        exit();
    }

}