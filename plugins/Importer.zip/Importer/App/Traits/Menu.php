<?php
/**
 * Created by PhpStorm.
 * User: fr0zen
 * Date: 13/05/2020
 * Time: 07:38 PM
 */

namespace App\Traits;


trait Menu{

    public function CreateAdminMenu(){
        add_menu_page(
            "Import",
            "Import",
            "administrator",
            "moviewp_tmdb",
            array($this,"load_page"),
            "dashicons-format-video",
            null
        );

        add_submenu_page(
            "moviewp_post",
            "The Movie DB Importer",
            "The Movie DB",
            "administrator",
            "moviewp_tmdb",
            array($this,"load_page")
        );
        add_submenu_page(
            "moviewp_post",
            "Movie Boot",
            "Movie Boot",
            "administrator",
            "moviewp_tmdb",
            array($this,"load_page")
        );
    }

    public function CustomAdminItemMenu(){
        global $submenu;
        @$submenu['moviewp_post'][0][0] = "Import";
    }

}