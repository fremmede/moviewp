<?php
/**
 * Created by PhpStorm.
 * User: fr0zen
 * Date: 22/12/2020
 * Time: 07:38 PM
 */

namespace App;

use App\Traits\Boot;
use App\Traits\Menu;
use App\Traits\Tools;
use TMDB\Tmdb;


class Bootstrap extends Tmdb {

    use Menu;
    use Boot;
    use Tools;
    
    public function __construct($api_key = "49101d62654e71a2931722642ac07e5e")
    {
        parent::__construct($api_key);
        $this->isMovieWP();
        add_action( 'admin_menu', array( $this, 'CreateAdminMenu' ) );
        if(!empty($_POST['action']))
        if($_POST['action']!="")
        if(isset($_POST['action'])){
            $wp_ajax_action = 'wp_ajax_'.$_POST['action'];
            add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
	     }
    }

    private function isMovieWP(){
        if(wp_get_theme()!='moviewp'){
            add_action("admin_menu",function (){
                if(is_plugin_active(Importer)){
                    //deactivate_plugins(Importer);
                }
            });

        }
    }

    public function load_page(){
        if($_GET['page'] == "moviewp_tmdb"){
        wp_enqueue_script(
            "moviewp_jquery",
            "https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"
        );
        wp_enqueue_script(
            "moviewp_popper",
            "https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        );
        wp_enqueue_script(
            "moviewp_bootstrap",
            "https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        );
        wp_enqueue_script(
            "moviewp_mdb",
            "https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/js/mdb.min.js"
        );
        wp_enqueue_style(
            "moviewp_font",
            "https://use.fontawesome.com/releases/v5.8.2/css/all.css"
        );
        wp_enqueue_style(
            "moviewp_bootstrap",
            "https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        );
        wp_enqueue_style(
            "moviewp_mdb",
            "https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/css/mdb.min.css"
        );
        wp_enqueue_style(
            "moviewp_style",
            plugin_dir_url(__DIR__)."App/public/assets/css/style.css"
        );
        wp_enqueue_script(
            "moviewp_js",
            plugin_dir_url(__DIR__)."App/public/assets/js/moviewp.js",
            ["jquery"],
            random_int(100000,1000000000)
        );
        wp_localize_script(
            "moviewp_js",
            "moviewp_ajax",
            ["url"=>admin_url("admin-ajax.php")]
        );
        }
        if($_GET['page'] == "moviewp_boot"){
            if(@$_GET['post']==''){
               exit();
            }else{
                $movie= get_post(@$_GET['post']);
                if(gettype($movie) == "NULL"){
                    exit();
                }
            }
        }
        if(file_exists(PLUGIN_DIR."/App/public/".$_GET['page'].".php")){
            include PLUGIN_DIR."/App/public/".$_GET['page'].".php";
        }else{
            include PLUGIN_DIR."/App/public/404.php";
        }
    }
    
}
